<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>strategynaveen</title>
    
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="main.css">
    
<script type="text/javascript">
    $(document).ready(function(){
        alert('hi guys its qoeking');
        document.getElementById('date4').style.display="none";

       $('#submit').click(function(event){
        event.preventDefault();
                $.ajax({
                    url : 'login_ins.php"',
                    method : 'POST',
                    data : $('#myform').serialize(),
                    success :function(data){
                        alert(data);
                        $("#myform")[0].reset();            
                    }

                });
        });

    });

   function mydate(){
       document.getElementById('date4').style.display="inline";
   }
   function mydate1(){
       document.getElementById('date4').style.display="none";
   }
</script>
</head>
<body class="parallax4">
        <!----navbar---->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark nav-atch w-100" >
	<a calss="navbar-brand " href="#" ><i class="fa fa-tint fa-2x icon"></i>Blooddonate</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsupportedcontent" aria-controls="navbarsupportedcontent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarsupportedcontent">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item active">
					<a class="nav-link nav-mar fn1" href="index.php"><i class="fa fa-home icon"></i>HOME<span class="sr-only">(current)</span></a>
				</li>
				<li class="nav-item">
					<a class="nav-link fn1" href="#" ><span class="fa fa-users icon"></span>GroupLOGIN</a>
				</li>
				<li class="nav-item">
					<a class="nav-link fn1" href="donar_reg.php"><span class="fa fa-user"></span>Donar Registration</a>
				</li>
				<li class="nav-item dropdown fn1">
					<a class="nav-link dropdown-toggle" href="#" id="navbardropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-plus icon"></i>PATIENT</a>
					<div class="dropdown-menu" arialabelledy="navbardropdown">
						<a class="dropdown-item" href="patient_register.php">REGISTER</a>
						<a class="dropdown-item" href="#">DETAILS</a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item" href="#">something else here</a>
					</div>
				</li>
				<li class="nav-item">
					<a  class="nav-link fn1" href="adminprof.php"><span class="fa fa-info-circle icon"></span>About</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " id="fn2" href="#" tabindex="-1" aria-disbled="true">GroupAdminLogin</a>
				</li>
			</ul>
		</div>
</nav>
 <!----navbar---->
 <br>
 <!-------------header--------------->
<div class="jumbotron op">
    <h1 class="text-center text-col sh2">DONAR LOGIN</h1>
</div>
<div class="container">
    <div class="row">
        <div class="col-lg-2"></div>
        <div class="col-lg-8">
            <div class="jumbotron op1 shadow-lg">
                <div class="row">
                    <div class="col-sm-4"></div>
                    <div class="col-sm-4">
                        <img src="reg.jpg" alt="" class="rounded-circle shadow-lg" height="130" width="130" srcset="">
                    </div>
                    <div class="col-sm-4"></div>
                </div>
                <br>
                <form id="myform" method="POST">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-lg-6">
                                <label for="user_id" class="lbl_name">UserId</label>
                            </div>
                            <div class="col-lg-6">
                                <div class="InputWithIcon">
                                    <input type="text" name="user_id" id="user_id" class="form-control form-control-lg" placeholder="Enter the UserId " required="true" >
                                    <i class="fa fa-id-badge"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-lg-6">
                                <label for="pass" class="lbl_name">Password</label>
                            </div>
                            <div class="col-lg-6">
                                <div class="InputWithIcon">
                                    <input type="password" name="pass" id="pass" class="form-control form-control-lg" placeholder="Enter The Password" required="true">
                                    <i class="fa fa-key"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
					    <div class="row">
					        <div class="col-lg-6">
					            <label for="" class="lbl_name">BloodGroup:</label>
						    </div>
						    <div class="col-lg-6">
						        <div class="InputWithIcon">
							        <select class="custom-select cust" id="blood_grp" name="blood_grp" required="true">
								        <option disabled selected>Choose Blood Group</option>
								        <option value="A+ve">A+ve</option>
								        <option value="B+ve">B+ve</option>
								        <option value="O+ve">O+ve</option>
								        <option value="AB+ve">AB+ve</option>
								        <option value="A-ve">A-ve</option>
								        <option value="B-ve">B-ve</option>
								        <option value="O-ve">O-ve</option>
						    	        <option value="AB-ve">AB-ve</option>
							        </select>
							        <i class="fa fa-tint"></i>
							    </div>
							</div>
						</div>
				    </div>
                    <br>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-lg-2"></div>
                            <div class="col-lg-8">
                                <h6 class="lbl_name">Already You Donate Blood:</h6>
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" class="custom-control-input" onclick="mydate()" id="defaultinline1" name="date_check">
                                    <label class="custom-control-label" for="defaultinline1" >YES</label>
                                </div>
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" class="custom-control-input"  onclick="mydate1()" name="date_check" id="defaultinline2">
                                    <label for="defaultinline2" class="custom-control-label">NO</label>
                                </div>
                            </div>
                            <div class="col-lg-2"></div>
                        </div>
                    </div>       
                    <div id="date4">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-lg-6">
                                    <label for="date"  class="lbl_name">Donate Date</label>
                                </div>
                                <div class="col-lg-6">
                                    <input type="date" name="donar_date" id="donar_date" class="form-control form-control-lg">
                                </div>
                            </div>
                        </div>
                    </div>          
                    <div class="row">
                        <div class="col-lg-4"></div>
                        <div class="col-lg-4">
                            <input type="submit" id="submit" value="Login" class="btn btn-lg btn-info">
                        </div>
                        <div class="col-lg-4"></div>
                    </div>
                </form>
            </div>
            <div class="col-lg-2"></div>
        </div>
    </div>
</div>
<!-----------------footer-------------------->	
<div class="footer">
		<div class="row">
			<div class="col-lg-6">
				<a href="index.php" class="foot-line">HOME</a>
				<br>
				<a href="donar_reg.php" class="foot-line">Donar Registration</a>
				<br>
				<a href="patient_register.php" class="foot-line">Patient Register</a>
			</div>
			<div class="col-lg-6">
				<a href="donar_reg.php" class="foot-line"></a>
				<a href="" class="foot-link"></a>
				<a href="" class="foot-link"></a>
			</div>
		</div>
		<div class=" text-center copy font-weight-bold text-white">COPYRIGHTS@STRATEGYSOFTWARES.COM</div>
</div>	        

<script type="text/javascript">
    $(document).ready(function(){
        alert('hi guys');
        $('#submit').click(function(event){
        event.preventDefault();
                $.ajax({
                    url : 'login_ins.php"',
                    method : 'POST',
                    data : $('#myform').serialize(),
                    success :function(data){
                        alert(data);
                        $("#myform")[0].reset();            
                    }

                });
        });

    });
</script>


</body>
</html>