<?php
session_start();
    //print_r($_POST);
    include('db_config.php');
        if($con->connect_error){
            die('connection failed'.$con->connect_error);
        }
        else {
            //echo "connection successfully";
            if ((empty($_POST['euserid'])) && (empty($_POST['epass']))) {
                header('location:emp_login.php');
            }
            elseif (empty($_POST['epass'])) {
                header('location:emp_login.php');
            }
            elseif (empty($_POST['euserid'])) {
                header('location:emp_login.php');
            }
            elseif (empty($_POST['e_blod_grp'])) {
                header('location:emp_login.php');
            }
            else{
                $euserid=$_POST['euserid'];
                $epass=$_POST['epass'];
                $eblood=$_POST['e_blod_grp'];

                $sql="SELECT  `e_user_id`, `e_pass` FROM `emp_donar` WHERE `e_user_id`='".$euserid."' AND `e_pass`='".$epass."' ";

                    $res=mysqli_query($con,$sql);
                    $row=mysqli_fetch_array($res);
                    $count=mysqli_num_rows($res);
                    if ($count==1) {
                    echo "<script>alert('login succesfully........');</script>";
                        if (empty($_POST['edate'])) {
                            $edate='null';
                        }
                        else{
                            $edate=$_POST['edate'];
                        }
                        $query="INSERT INTO `emp_donar1`(`e_userid`, `e_pass`, `e_donar_date`, `e_blood_grp`) VALUES ('$euserid','$epass','$edate','$eblood')";
                        if ($con->query($query)==true) {
                            echo "<script>alert('***********inserted successfully**********');</script>";
                            $_SESSION['eblood_grp']=$eblood;
                            header('location:emp_details.php');
                        }
                    }
                    else{
                        // echo "error ".$con->$sql."";
                        echo "<script>alert('please incorrect pasword and user id');</script>";
                        header('location:emp_login.php');
                    }
              
            }

        }


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StrategyNaveen</title>
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body class="parallax4">
        <!----navbar---->
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark nav-atch w-100" >
                <a calss="navbar-brand " href="#" ><i class="fa fa-tint fa-2x icon"></i>Blooddonate</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsupportedcontent" aria-controls="navbarsupportedcontent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarsupportedcontent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link nav-mar fn1" href="index.php"><i class="fa fa-home icon"></i>HOME<span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link fn1" href="group_login.php" ><span class="fa fa-users icon"></span>GroupLOGIN</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link fn1" href="donar_reg.php"><span class="fa fa-user"></span>Donar Registration</a>
                        </li>
                        <li class="nav-item dropdown fn1">
                            <a class="nav-link dropdown-toggle" href="#" id="navbardropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-plus icon"></i>PATIENT</a>
                            <div class="dropdown-menu" arialabelledy="navbardropdown">
                                <a class="dropdown-item" href="patient_register.php">REGISTER</a>
                                <a class="dropdown-item" href="group_login.php">GroupLogin</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#">something else here</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a  class="nav-link fn1" href="adminprof.php"><span class="fa fa-info-circle icon"></span>About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link " id="fn2" href="#" tabindex="-1" aria-disbled="true">GroupAdminLogin</a>
                        </li>
                    </ul>
                    
                </div>
            </nav>
            <!----navbar---->
            <br>
            <div class="jumbotron op">
                <h1 class="text-center text-col sh2">DONAR LOGIN</h1>
            </div>
</body>
</html>