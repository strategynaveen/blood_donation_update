<?php
	include("db_config.php");
?>
<h4 class="page-header"><i class="fa fa-users"></i>Patient List</h4>
<table class="table">
	<tr>
		<th>paient_id</th>
		<th>Patient_name</th>
		<th>bloodgroup</th>
		<th>hospital_name</th>
	</tr>
	<?php
		if ($con->connect_error) {
			die('connection failed'.$con->connect_error);

		}
		else{
			echo "connection successfully";
			$sql="select * from patient";
			$res=$con->query($sql);
			if ($res->num_rows>0) {

				while ($row=$res->fetch_assoc()) {
					echo "<tr>";
					echo "<td>{$row["pati_id"]}</td>";
					echo "<td>{$row["pat_name"]}</td>";
					echo "<td>{$row["bloood_grp"]}</td>";
					echo "<td>{$row["hospital_name"]}</td>";
					echo "</tr>";	
				}
			}
		}
	?>
</table>