-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 13, 2021 at 12:19 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blood`
--

-- --------------------------------------------------------

--
-- Table structure for table `accept1`
--

CREATE TABLE `accept1` (
  `pati_id` bigint(70) DEFAULT NULL,
  `userid` varchar(60) DEFAULT NULL,
  `blood_grp` varchar(60) DEFAULT NULL,
  `dunit` int(70) DEFAULT NULL,
  `punit` int(80) DEFAULT NULL,
  `name` varchar(70) DEFAULT NULL,
  `mobile` bigint(70) DEFAULT NULL,
  `accept_date` date DEFAULT NULL,
  `old_date` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accept1`
--

INSERT INTO `accept1` (`pati_id`, `userid`, `blood_grp`, `dunit`, `punit`, `name`, `mobile`, `accept_date`, `old_date`) VALUES
(7579374829, 'naveen', 'A+ve', 1, 0, 'naveen', 6379617916, '2021-08-25', ''),
(7579374830, 'harish', 'A+ve', 4, 3, 'harish', 1234567890, '2021-08-25', '2020-04-13');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `userid` varchar(100) NOT NULL,
  `username` varchar(90) NOT NULL,
  `password` varchar(60) NOT NULL,
  `dob` date NOT NULL,
  `mobile` bigint(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`userid`, `username`, `password`, `dob`, `mobile`) VALUES
('naveen', 'naveen', 'nk456', '2000-04-18', 9942933262);

-- --------------------------------------------------------

--
-- Table structure for table `emp_donar`
--

CREATE TABLE `emp_donar` (
  `e_name` varchar(60) DEFAULT NULL,
  `e_age` int(50) DEFAULT NULL,
  `e_gender` varchar(60) DEFAULT NULL,
  `e_comp_name` varchar(60) DEFAULT NULL,
  `e_dep_name` varchar(60) DEFAULT NULL,
  `e_phone_no` bigint(70) DEFAULT NULL,
  `e_mail_id` varchar(60) DEFAULT NULL,
  `e_add` varchar(90) DEFAULT NULL,
  `e_blood_grp` varchar(80) DEFAULT NULL,
  `e_user_id` varchar(90) NOT NULL,
  `e_pass` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_donar`
--

INSERT INTO `emp_donar` (`e_name`, `e_age`, `e_gender`, `e_comp_name`, `e_dep_name`, `e_phone_no`, `e_mail_id`, `e_add`, `e_blood_grp`, `e_user_id`, `e_pass`) VALUES
('harish', 21, 'Male', 'bhaann industries', 'technical department', 1234567890, 'harish@gmail.com', 'madurai', 'A+ve', 'harish', 'harish123');

-- --------------------------------------------------------

--
-- Table structure for table `emp_donar1`
--

CREATE TABLE `emp_donar1` (
  `e_userid` varchar(50) DEFAULT NULL,
  `e_pass` varchar(60) DEFAULT NULL,
  `e_donar_date` date DEFAULT NULL,
  `e_blood_grp` varchar(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `other_donar`
--

CREATE TABLE `other_donar` (
  `o_name` varchar(80) DEFAULT NULL,
  `o_age` int(80) DEFAULT NULL,
  `o_gender` varchar(80) DEFAULT NULL,
  `o_phone_no` bigint(90) DEFAULT NULL,
  `o_mail_id` varchar(90) DEFAULT NULL,
  `o_add` varchar(90) DEFAULT NULL,
  `o_user_id` varchar(90) NOT NULL,
  `o_pass` varchar(80) DEFAULT NULL,
  `o_blood_grp` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `other_donar`
--

INSERT INTO `other_donar` (`o_name`, `o_age`, `o_gender`, `o_phone_no`, `o_mail_id`, `o_add`, `o_user_id`, `o_pass`, `o_blood_grp`) VALUES
('avinash', 20, 'Male', 987654321, 'avinash@gmail.com', 'pambannagar\r\nmadurai', 'avinash', 'avinash123', 'O+ve');

-- --------------------------------------------------------

--
-- Table structure for table `other_donar1`
--

CREATE TABLE `other_donar1` (
  `o_userid` varchar(90) DEFAULT NULL,
  `o_pass` varchar(70) DEFAULT NULL,
  `o_donar_date` date DEFAULT NULL,
  `o_blood_grp` varchar(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `pati_id` bigint(100) NOT NULL,
  `pat_name` varchar(100) DEFAULT NULL,
  `pat_age` int(50) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `bloood_grp` varchar(20) DEFAULT NULL,
  `act_mobile` bigint(60) DEFAULT NULL,
  `rel_name` varchar(60) DEFAULT NULL,
  `rel_mobile` bigint(60) DEFAULT NULL,
  `hospital_name` varchar(90) DEFAULT NULL,
  `unit` int(40) DEFAULT NULL,
  `last_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pati_id`, `pat_name`, `pat_age`, `reason`, `bloood_grp`, `act_mobile`, `rel_name`, `rel_mobile`, `hospital_name`, `unit`, `last_date`) VALUES
(7579374829, 'navin', 20, 'head operation', 'A+ve', 9942933262, 'naveen kumar', 6379617916, 'madurai gh', 0, '2020-07-24'),
(7579374830, 'ashok', 21, 'heard operation', 'A+ve', 7094341464, 'naveen kumar', 6379617916, 'madurai gh', 3, '2020-07-24'),
(7579374831, 'vijay', 21, 'heard operation', 'B+ve', 8248419066, 'naveen', 9942933262, 'madurai gh', -1, '2020-08-10');

-- --------------------------------------------------------

--
-- Table structure for table `stud_donar`
--

CREATE TABLE `stud_donar` (
  `stud_name` varchar(70) DEFAULT NULL,
  `stud_reg` varchar(60) DEFAULT NULL,
  `gender` varchar(60) DEFAULT NULL,
  `mailid` varchar(80) DEFAULT NULL,
  `address` varchar(80) DEFAULT NULL,
  `phone_no` bigint(70) DEFAULT NULL,
  `user_id` varchar(70) NOT NULL,
  `pass` varchar(70) DEFAULT NULL,
  `clg_name` varchar(80) DEFAULT NULL,
  `dept` varchar(80) DEFAULT NULL,
  `blood_grp` varchar(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_donar`
--

INSERT INTO `stud_donar` (`stud_name`, `stud_reg`, `gender`, `mailid`, `address`, `phone_no`, `user_id`, `pass`, `clg_name`, `dept`, `blood_grp`) VALUES
('naveen kumar', '910018104304', 'Male', 'naveenkumar709434@gmail.com', '79/a pallar mettu street \r\nthirupparankundream\r\nmadurai', 6379617916, 'naveen', 'naveen123', 'anna university regional campus madurai', 'cse', 'A+ve');

-- --------------------------------------------------------

--
-- Table structure for table `stud_donar1`
--

CREATE TABLE `stud_donar1` (
  `userid` varchar(60) DEFAULT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `donar_date` date DEFAULT NULL,
  `blood_grp` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accept1`
--
ALTER TABLE `accept1`
  ADD KEY `pati_id` (`pati_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `emp_donar`
--
ALTER TABLE `emp_donar`
  ADD PRIMARY KEY (`e_user_id`);

--
-- Indexes for table `emp_donar1`
--
ALTER TABLE `emp_donar1`
  ADD KEY `e_userid` (`e_userid`);

--
-- Indexes for table `other_donar`
--
ALTER TABLE `other_donar`
  ADD PRIMARY KEY (`o_user_id`);

--
-- Indexes for table `other_donar1`
--
ALTER TABLE `other_donar1`
  ADD KEY `o_userid` (`o_userid`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`pati_id`);

--
-- Indexes for table `stud_donar`
--
ALTER TABLE `stud_donar`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `stud_donar1`
--
ALTER TABLE `stud_donar1`
  ADD KEY `userid` (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `pati_id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7579374832;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accept1`
--
ALTER TABLE `accept1`
  ADD CONSTRAINT `accept1_ibfk_1` FOREIGN KEY (`pati_id`) REFERENCES `patient` (`pati_id`);

--
-- Constraints for table `emp_donar1`
--
ALTER TABLE `emp_donar1`
  ADD CONSTRAINT `emp_donar1_ibfk_1` FOREIGN KEY (`e_userid`) REFERENCES `emp_donar` (`e_user_id`);

--
-- Constraints for table `other_donar1`
--
ALTER TABLE `other_donar1`
  ADD CONSTRAINT `other_donar1_ibfk_1` FOREIGN KEY (`o_userid`) REFERENCES `other_donar` (`o_user_id`);

--
-- Constraints for table `stud_donar1`
--
ALTER TABLE `stud_donar1`
  ADD CONSTRAINT `stud_donar1_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `stud_donar` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
